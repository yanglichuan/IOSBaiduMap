var searchData=
[
  ['origin',['origin',['../struct_b_m_k_map_rect.html#aeeee8bcaabf5c65e222f1891009325f1',1,'BMKMapRect']]]
];
