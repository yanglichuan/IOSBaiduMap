var searchData=
[
  ['vehicleinfo',['vehicleInfo',['../interface_b_m_k_transit_step.html#aa8fd99fdc509dbccab356e9388974978',1,'BMKTransitStep']]],
  ['visiblemaprect',['visibleMapRect',['../interface_b_m_k_map_view.html#a35576ab39592ef50d1190c2b672c0923',1,'BMKMapView']]]
];
