//
//  MyAnimatedAnnotation.h
//  IphoneMapSdkDemo
//
//  Created by wzy on 14-11-27.
//  Copyright (c) 2014年 Baidu. All rights reserved.
//

#import "BMKPointAnnotation.h"

@interface MyAnimatedAnnotation : BMKPointAnnotation

@end
