//
//  MyAnimatedAnnotation.m
//  IphoneMapSdkDemo
//
//  Created by wzy on 14-11-27.
//  Copyright (c) 2014年 Baidu. All rights reserved.
//

#import "MyAnimatedAnnotation.h"

@implementation MyAnimatedAnnotation

@end
